package com.example.iconchanger;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK_IMAGE = 1001;
    PackageManager pm;
    ArrayList<ResolveInfo> apps = new ArrayList<>();
    ArrayList<ResolveInfo> allApps = new ArrayList<>();
    ArrayAdapter<String> adapter;
    ArrayList<String> labels = new ArrayList<>();
    ResolveInfo selected;
    ImageView preview;
    Uri selectedUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        pm = getPackageManager();
        loadApps();

        EditText search = findViewById(R.id.search);
        ListView list = findViewById(R.id.appsList);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(adapter);

        list.setOnItemClickListener((p,v,pos,id) -> {
            selected = apps.get(pos);
            selectedUri = null;
            showIconDialog();
        });

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ filter(s.toString()); }
            public void afterTextChanged(android.text.Editable e){}
        });
    }

    void loadApps() {
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        allApps.clear();
        allApps.addAll(pm.queryIntentActivities(i, PackageManager.MATCH_ALL));
        Collections.sort(allApps, (a,b) -> a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        apps.clear();
        apps.addAll(allApps);
        labels.clear();
        for (ResolveInfo r: apps) labels.add(r.loadLabel(pm).toString());
    }

    void filter(String q) {
        apps.clear();
        String query = q.trim().toLowerCase(Locale.ROOT);
        for (ResolveInfo r : allApps) {
            String name = r.loadLabel(pm).toString();
            if (query.isEmpty() || name.toLowerCase(Locale.ROOT).contains(query)) {
                apps.add(r);
            }
        }
        labels.clear();
        for (ResolveInfo r : apps) labels.add(r.loadLabel(pm).toString());
        adapter.notifyDataSetChanged();
    }

    void showIconDialog() {
        View v = getLayoutInflater().inflate(R.layout.dialog_icon, null);
        preview = v.findViewById(R.id.preview);
        preview.setImageDrawable(selected.loadIcon(pm));
        Button choose = v.findViewById(R.id.choose);
        Button create = v.findViewById(R.id.create);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("تغيير أيقونة: " + selected.loadLabel(pm))
                .setView(v).create();

        choose.setOnClickListener(x -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("image/*");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(pick, PICK_IMAGE);
        });

        create.setOnClickListener(x -> {
            if (selectedUri == null) {
                Toast.makeText(this, "اختر صورة أولًا", Toast.LENGTH_SHORT).show();
                return;
            }
            createShortcut(selected, selectedUri);
            dlg.dismiss();
        });
        dlg.show();
    }

    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if (req == PICK_IMAGE && result == RESULT_OK && data != null) {
            selectedUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                    selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch(Exception ignored) {}
            if (preview != null) preview.setImageURI(selectedUri);
        }
    }

    android.graphics.drawable.Icon createShortcutIcon(Uri uri) {
        try {
            android.graphics.Bitmap bitmap;
            try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                bitmap = android.graphics.BitmapFactory.decodeStream(in);
            }
            if (bitmap == null) throw new Exception("تعذر قراءة الصورة");

            int size = 192;
            float scale = Math.min((float) size / bitmap.getWidth(), (float) size / bitmap.getHeight());
            int w = Math.max(1, Math.round(bitmap.getWidth() * scale));
            int h = Math.max(1, Math.round(bitmap.getHeight() * scale));
            android.graphics.Bitmap scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, w, h, true);
            return android.graphics.drawable.Icon.createWithAdaptiveBitmap(scaled);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر استخدام الصورة كأيقونة", Toast.LENGTH_LONG).show();
            return android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.sym_def_app_icon);
        }
    }

    void createShortcut(ResolveInfo app, Uri iconUri) {
        String packageName = app.activityInfo.packageName;
        String activityName = app.activityInfo.name;
        String id = "custom_" + packageName + "_" + System.currentTimeMillis();

        Intent target = new Intent(this, ShortcutProxyActivity.class);
        target.putExtra("package", packageName);
        target.putExtra("activity", activityName);
        target.putExtra("iconUri", iconUri.toString());

        if (Build.VERSION.SDK_INT >= 26) {
            android.content.pm.ShortcutManager sm = getSystemService(android.content.pm.ShortcutManager.class);
            if (sm != null && sm.isRequestPinShortcutSupported()) {
                android.content.pm.ShortcutInfo info =
                    new android.content.pm.ShortcutInfo.Builder(this, id)
                    .setShortLabel(app.loadLabel(pm).toString())
                    .setLongLabel("فتح " + app.loadLabel(pm))
                    .setIcon(createShortcutIcon(iconUri))
                    .setIntent(target)
                    .build();
                sm.requestPinShortcut(info, null);
                Toast.makeText(this, "سيظهر طلب إضافة الاختصار على الشاشة الرئيسية", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "اللانشر الحالي لا يدعم تثبيت الاختصارات", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "هذه الخاصية تحتاج Android 8 أو أحدث", Toast.LENGTH_LONG).show();
        }
    }
}
