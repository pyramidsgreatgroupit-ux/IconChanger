package com.example.iconchanger;

import android.app.Activity;
import android.content.*;
import android.os.Bundle;

public class ShortcutProxyActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        String pkg = getIntent().getStringExtra("package");
        String activity = getIntent().getStringExtra("activity");
        try {
            Intent launch = new Intent();
            launch.setComponent(new ComponentName(pkg, activity));
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(launch);
        } catch(Exception e) {
            Intent fallback = getPackageManager().getLaunchIntentForPackage(pkg);
            if (fallback != null) startActivity(fallback);
        }
        finish();
    }
}
