package com.example.iconchanger;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK_IMAGE = 1001;
    PackageManager pm;
    ArrayList<ResolveInfo> apps = new ArrayList<>();
    ArrayAdapter<String> adapter;
    ArrayList<String> labels = new ArrayList<>();
    ResolveInfo selected;
    ImageView preview;
    Uri selectedUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        pm = getPackageManager();
        loadApps();

        EditText search = findViewById(R.id.search);
        ListView list = findViewById(R.id.appsList);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels);
        list.setAdapter(adapter);

        list.setOnItemClickListener((p,v,pos,id) -> {
            selected = apps.get(pos);
            showIconDialog();
        });

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ filter(s.toString()); }
            public void afterTextChanged(android.text.Editable e){}
        });
    }

    void loadApps() {
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        apps.clear();
        apps.addAll(pm.queryIntentActivities(i, PackageManager.MATCH_ALL));
        Collections.sort(apps, (a,b) -> a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        labels.clear();
        for (ResolveInfo r: apps) labels.add(r.loadLabel(pm).toString());
    }

    void filter(String q) {
        ArrayList<String> old = new ArrayList<>(labels);
        labels.clear();
        ArrayList<ResolveInfo> filtered = new ArrayList<>();
        for (ResolveInfo r: apps) {
            String name = r.loadLabel(pm).toString();
            if (name.toLowerCase().contains(q.toLowerCase())) {
                labels.add(name);
                filtered.add(r);
            }
        }
        // Keep the displayed positions aligned with filtered results.
        apps.clear(); apps.addAll(filtered);
        adapter.notifyDataSetChanged();
        if (q.isEmpty()) loadApps();
    }

    void showIconDialog() {
        View v = getLayoutInflater().inflate(R.layout.dialog_icon, null);
        preview = v.findViewById(R.id.preview);
        preview.setImageDrawable(selected.loadIcon(pm));
        Button choose = v.findViewById(R.id.choose);
        Button create = v.findViewById(R.id.create);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("تغيير أيقونة: " + selected.loadLabel(pm))
                .setView(v).create();

        choose.setOnClickListener(x -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("image/*");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(pick, PICK_IMAGE);
        });

        create.setOnClickListener(x -> {
            if (selectedUri == null) {
                Toast.makeText(this, "اختر صورة أولًا", Toast.LENGTH_SHORT).show();
                return;
            }
            createShortcut(selected, selectedUri);
            dlg.dismiss();
        });
        dlg.show();
    }

    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if (req == PICK_IMAGE && result == RESULT_OK && data != null) {
            selectedUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                    selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch(Exception ignored) {}
            if (preview != null) preview.setImageURI(selectedUri);
        }
    }

    void createShortcut(ResolveInfo app, Uri iconUri) {
        String packageName = app.activityInfo.packageName;
        String activityName = app.activityInfo.name;
        String id = "custom_" + packageName + "_" + System.currentTimeMillis();

        Intent target = new Intent(this, ShortcutProxyActivity.class);
        target.putExtra("package", packageName);
        target.putExtra("activity", activityName);
        target.putExtra("iconUri", iconUri.toString());

        if (Build.VERSION.SDK_INT >= 26) {
            android.content.pm.ShortcutManager sm = getSystemService(android.content.pm.ShortcutManager.class);
            if (sm != null && sm.isRequestPinShortcutSupported()) {
                android.content.pm.ShortcutInfo info =
                    new android.content.pm.ShortcutInfo.Builder(this, id)
                    .setShortLabel(app.loadLabel(pm).toString())
                    .setLongLabel("فتح " + app.loadLabel(pm))
                    .setIcon(android.graphics.drawable.Icon.createWithContentUri(iconUri.toString()))
                    .setIntent(target)
                    .build();
                sm.requestPinShortcut(info, null);
                Toast.makeText(this, "سيظهر طلب إضافة الاختصار على الشاشة الرئيسية", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "اللانشر الحالي لا يدعم تثبيت الاختصارات", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "هذه الخاصية تحتاج Android 8 أو أحدث", Toast.LENGTH_LONG).show();
        }
    }
}
